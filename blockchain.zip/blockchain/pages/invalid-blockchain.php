<?php require '../includes/header.php' ?>

<div class="container">
    <div class="row mt-5">
        <div class="col">
            <h1>Block(s) Tampered</h1>
            <p>
                Block(s) tampering has been detected. The blockchain is invalid.
            </p>
        </div>
    </div>
</div>

<?php require '../includes/footer.php' ?>