
<!-- navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-color:#666666 !important">
    <div class="container-fluid">
        <a class="navbar-brand" href="../index.php" style="font-weight:bold; color:#FFFFFF;">Block Chain Voting System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown" style="float:right; font-weight:bold; color:#FFFFFF !important; position:absolute; right:10px;">
            <ul class="navbar-nav">
                 <li class="nav-item">
                    <a class="nav-link" href="../index.php" id="navbarDropdownMenuLink" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false" style="color:#FFFFFF !important;">
                        Home
                    </a>
                </li>
				<li class="nav-item">
                    <a class="nav-link" href="about.php" id="navbarDropdownMenuLink" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false" style="color:#FFFFFF !important;">
                        About Blockchain Voting System
                    </a>
                </li>
				<li class="nav-item">
                    <a class="nav-link" href="contact-us.php" id="navbarDropdownMenuLink" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false" style="color:#FFFFFF !important;">
                       Contact Us
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>