
<script src="../scripts/main.js"></script>
</body>
</html>